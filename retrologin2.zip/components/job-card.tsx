"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { formatDate, formatSalary } from "@/lib/utils"
import Image from "next/image"

interface Job {
  id: string
  title: string
  company: string
  logo: string
  location: string
  type: string
  salary: { min: number; max: number }
  posted: string
  description: string
  tags: string[]
}

interface JobCardProps {
  job: Job
  onApply: (jobId: string) => void
  isApplied?: boolean
}

export function JobCard({ job, onApply, isApplied }: JobCardProps) {
  return (
    <Card className="overflow-hidden transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 hover:border-primary/50">
      <CardHeader className="p-4 pb-0">
        <div className="flex items-start gap-4">
          <div className="h-12 w-12 rounded-md overflow-hidden bg-muted flex items-center justify-center">
            <Image
              src={job.logo || "/placeholder.svg"}
              alt={job.company}
              width={48}
              height={48}
              className="object-cover"
            />
          </div>
          <div className="flex-1 space-y-1">
            <h3 className="font-semibold line-clamp-1">{job.title}</h3>
            <p className="text-sm text-muted-foreground">{job.company}</p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <div className="space-y-3">
          <div className="flex items-center text-sm text-muted-foreground">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="mr-1"
            >
              <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
              <circle cx="12" cy="10" r="3" />
            </svg>
            {job.location}
          </div>
          <div className="flex items-center text-sm text-muted-foreground">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="mr-1"
            >
              <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
              <line x1="16" x2="16" y1="2" y2="6" />
              <line x1="8" x2="8" y1="2" y2="6" />
              <line x1="3" x2="21" y1="10" y2="10" />
              <path d="M8 14h.01" />
              <path d="M12 14h.01" />
              <path d="M16 14h.01" />
              <path d="M8 18h.01" />
              <path d="M12 18h.01" />
              <path d="M16 18h.01" />
            </svg>
            Posted {formatDate(job.posted)}
          </div>
          <div className="flex items-center text-sm text-muted-foreground">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="mr-1"
            >
              <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
            </svg>
            {formatSalary(job.salary.min, job.salary.max)}
          </div>
          <p className="text-sm line-clamp-2">{job.description}</p>
          <div className="flex flex-wrap gap-2 pt-2">
            {job.tags.slice(0, 3).map((tag) => (
              <Badge key={tag} variant="secondary" className="text-xs">
                {tag}
              </Badge>
            ))}
            {job.tags.length > 3 && (
              <Badge variant="outline" className="text-xs">
                +{job.tags.length - 3} more
              </Badge>
            )}
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        {isApplied ? (
          <Badge className="w-full py-1.5 flex justify-center bg-green-600/20 text-green-500 hover:bg-green-600/20">
            Application Submitted
          </Badge>
        ) : (
          <Button onClick={() => onApply(job.id)} className="w-full">
            Apply Now
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}

