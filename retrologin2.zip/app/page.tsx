"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { useToast } from "@/components/ui/use-toast"

export default function Home() {
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [loginData, setLoginData] = useState({
    username: "",
    password: "",
  })

  const handleLoginChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setLoginData((prev) => ({ ...prev, [name]: value }))
  }

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Authenticate user via API
      const response = await fetch("/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(loginData),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Invalid username or password")
      }

      // Store current user in localStorage
      localStorage.setItem("currentUser", JSON.stringify(data))

      toast({
        title: "Login successful!",
        description: "Welcome back to Work Connect.",
        variant: "default",
      })

      // Redirect to dashboard
      setTimeout(() => {
        router.push("/dashboard")
      }, 1000)
    } catch (error: any) {
      toast({
        title: "Login failed",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <main className="min-h-screen flex flex-col bg-brand-navy">
      {/* Top Bar */}
      <div className="w-full bg-brand-navy border-b border-border/20 py-4">
        <div className="container flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-vMfrZLih1W3LkSGeqZJj23w007Ybh2.png"
              alt="Work Connect Logo"
              width={32}
              height={32}
              className="w-8 h-8"
            />
            <span className="font-bold text-xl text-white">Work Connect</span>
          </div>

          <div className="hidden md:flex items-center gap-3">
            <Input
              placeholder="Username"
              className="w-48 h-9 bg-background/10 border-border/30 text-white placeholder:text-white/50"
              value={loginData.username}
              name="username"
              onChange={handleLoginChange}
            />
            <Input
              placeholder="Password"
              type="password"
              className="w-48 h-9 bg-background/10 border-border/30 text-white placeholder:text-white/50"
              value={loginData.password}
              name="password"
              onChange={handleLoginChange}
            />
            <Button size="sm" onClick={handleLoginSubmit} className="bg-primary hover:bg-primary/90">
              Login
            </Button>
          </div>

          <div className="md:hidden flex items-center gap-3">
            <Link href="/login">
              <Button size="sm" variant="outline" className="border-primary/50 text-primary">
                Login
              </Button>
            </Link>
            <Link href="/register">
              <Button size="sm">Register</Button>
            </Link>
          </div>
        </div>
      </div>

      <section className="flex-1 pt-24 pb-12">
        <div className="container flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1 space-y-6 animate-fade-up">
            <h1 className="text-4xl md:text-6xl font-bold leading-tight">
              <span className="gradient-text">Bridging You</span> To Your Future
            </h1>
            <p className="text-lg text-muted-foreground max-w-md">
              Connect with top employers and find your dream job with Work Connect, the professional job portal designed
              for modern careers.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/register">
                <Button size="lg" className="w-full sm:w-auto">
                  Get Started
                </Button>
              </Link>
              <Link href="/login">
                <Button size="lg" variant="outline" className="w-full sm:w-auto gradient-border">
                  Login
                </Button>
              </Link>
            </div>
          </div>
          <div className="flex-1 flex justify-center">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/workconnect-QF8ACZmgXX8qHFp2h8Y83aeS6TuYt5.png"
              alt="Work Connect"
              width={500}
              height={400}
              className="animate-fade-in"
              priority
            />
          </div>
        </div>
      </section>

      <section id="features" className="py-20 bg-card">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">
            <span className="gradient-text">Features</span> That Connect
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Smart Job Matching",
                description:
                  "Our AI-powered system matches your skills and experience with the perfect job opportunities.",
                icon: (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="lucide lucide-brain-circuit"
                  >
                    <path d="M12 4.5a2.5 2.5 0 0 0-4.96-.46 2.5 2.5 0 0 0-1.98 3 2.5 2.5 0 0 0-1.32 4.24 3 3 0 0 0 .34 5.58 2.5 2.5 0 0 0 2.96 3.08 2.5 2.5 0 0 0 4.91.05L12 20V4.5Z" />
                    <path d="M16 8V5c0-1.1.9-2 2-2" />
                    <path d="M12 13h4" />
                    <path d="M12 18h6a2 2 0 0 1 2 2v1" />
                    <path d="M12 8h8" />
                    <path d="M20.5 8a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0Z" />
                    <path d="M12 8h8" />
                    <path d="M20.5 8a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0Z" />
                    <path d="M16.5 13a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0Z" />
                    <path d="M20.5 21a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0Z" />
                    <path d="M18.5 3a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0Z" />
                  </svg>
                ),
              },
              {
                title: "Professional Profile",
                description:
                  "Create a standout profile that showcases your skills, experience, and career aspirations.",
                icon: (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="lucide lucide-user-circle-2"
                  >
                    <path d="M18 20a6 6 0 0 0-12 0" />
                    <circle cx="12" cy="10" r="4" />
                    <circle cx="12" cy="12" r="10" />
                  </svg>
                ),
              },
              {
                title: "One-Click Apply",
                description: "Apply to jobs with a single click, making your job search efficient and stress-free.",
                icon: (
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="lucide lucide-mouse-pointer-click"
                  >
                    <path d="m9 9 5 12 1.8-5.2L21 14Z" />
                    <path d="M7.2 2.2 8 5.1" />
                    <path d="m5.1 8-2.9-.8" />
                    <path d="M14 4.1 12 6" />
                    <path d="m6 12-1.9 2" />
                  </svg>
                ),
              },
            ].map((feature, index) => (
              <div
                key={index}
                className="bg-background p-6 rounded-lg border border-border/50 hover:border-primary/50 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5"
              >
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4 text-primary">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="border-t border-border/40 py-8">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-vMfrZLih1W3LkSGeqZJj23w007Ybh2.png"
                alt="Work Connect Logo"
                width={32}
                height={32}
                className="w-8 h-8"
              />
              <span className="font-bold">Work Connect</span>
            </div>
            <div className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} Work Connect. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </main>
  )
}

