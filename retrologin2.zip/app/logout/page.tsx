"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"

export default function Logout() {
  const router = useRouter()

  useEffect(() => {
    // Clear user session
    localStorage.removeItem("currentUser")

    // Redirect to login page after a short delay
    const timer = setTimeout(() => {
      router.push("/login")
    }, 2000)

    return () => clearTimeout(timer)
  }, [router])

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background">
      <div className="text-center">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Screenshot%202025-03-16%20140112-fkBDvgVur3LGNgat4ZQfB0yFclE4i5.png"
          alt="Work Connect Logo"
          width={80}
          height={80}
          className="mx-auto mb-6"
        />
        <h1 className="text-2xl font-bold mb-2">Logging you out...</h1>
        <p className="text-muted-foreground">Thank you for using Work Connect</p>
      </div>
    </div>
  )
}

