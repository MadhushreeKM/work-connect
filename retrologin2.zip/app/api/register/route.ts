import { type NextRequest, NextResponse } from "next/server"
import { createUser } from "@/lib/file-utils"

export async function POST(request: NextRequest) {
  try {
    const userData = await request.json()

    // Validate required fields
    if (!userData.username || !userData.password || !userData.email || !userData.dob) {
      return NextResponse.json({ error: "All fields are required" }, { status: 400 })
    }

    // Create user
    const newUser = createUser(userData)

    // Return user without password for security
    const { password, ...userWithoutPassword } = newUser
    return NextResponse.json(userWithoutPassword)
  } catch (error: any) {
    console.error("Registration error:", error)
    return NextResponse.json({ error: error.message || "Registration failed" }, { status: 500 })
  }
}

