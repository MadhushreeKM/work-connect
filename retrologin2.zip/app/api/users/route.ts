import { type NextRequest, NextResponse } from "next/server"
import { readUsersFromFile, createUser } from "@/lib/api-utils"

// GET /api/users - Get all users
export async function GET() {
  try {
    const users = readUsersFromFile()
    return NextResponse.json(users)
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

// POST /api/users - Create a new user
export async function POST(request: NextRequest) {
  try {
    const userData = await request.json()

    // Validate required fields
    if (!userData.username || !userData.password || !userData.email || !userData.dob) {
      return NextResponse.json({ error: "All fields are required" }, { status: 400 })
    }

    const newUser = createUser(userData)
    return NextResponse.json(newUser)
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 400 })
  }
}

