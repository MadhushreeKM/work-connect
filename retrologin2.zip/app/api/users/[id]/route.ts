import { type NextRequest, NextResponse } from "next/server"
import { readUsersFromFile, updateUser } from "@/lib/file-utils"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const users = readUsersFromFile()
    const user = users.find((u: any) => u.id === params.id)

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Return user without password for security
    const { password, ...userWithoutPassword } = user
    return NextResponse.json(userWithoutPassword)
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const userData = await request.json()
    const updatedUser = updateUser(params.id, userData)

    // Return user without password for security
    const { password, ...userWithoutPassword } = updatedUser
    return NextResponse.json(userWithoutPassword)
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 400 })
  }
}

