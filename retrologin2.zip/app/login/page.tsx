"use client"

import type React from "react"
import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"

export default function Login() {
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [loginData, setLoginData] = useState({
    username: "",
    password: "",
  })
  const [headerLoginData, setHeaderLoginData] = useState({
    username: "",
    password: "",
  })

  const handleLoginChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setLoginData((prev) => ({ ...prev, [name]: value }))
  }

  const handleHeaderLoginChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setHeaderLoginData((prev) => ({ ...prev, [name]: value }))
  }

  const handleLoginSubmit = async (e: React.FormEvent, data = loginData) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Authenticate user via API
      const response = await fetch("/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      const responseData = await response.json()

      if (!response.ok) {
        throw new Error(responseData.error || "Invalid username or password")
      }

      // Store current user in localStorage
      localStorage.setItem("currentUser", JSON.stringify(responseData))

      toast({
        title: "Login successful!",
        description: "Welcome back to Work Connect.",
        variant: "default",
      })

      // Redirect to dashboard
      setTimeout(() => {
        router.push("/dashboard")
      }, 1000)
    } catch (error: any) {
      toast({
        title: "Login failed",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleHeaderLoginSubmit = (e: React.FormEvent) => {
    handleLoginSubmit(e, headerLoginData)
  }

  return (
    <div className="min-h-screen flex flex-col bg-brand-navy">
      {/* Top Bar */}
      <div className="w-full bg-brand-navy border-b border-border/20 py-4">
        <div className="container flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-vMfrZLih1W3LkSGeqZJj23w007Ybh2.png"
              alt="Work Connect Logo"
              width={32}
              height={32}
              className="w-8 h-8"
            />
            <span className="font-bold text-xl text-white">Work Connect</span>
          </div>

          <div className="hidden md:flex items-center gap-3">
            <Input
              placeholder="Username"
              className="w-48 h-9 bg-background/10 border-border/30 text-white placeholder:text-white/50"
              value={headerLoginData.username}
              name="username"
              onChange={handleHeaderLoginChange}
            />
            <Input
              placeholder="Password"
              type="password"
              className="w-48 h-9 bg-background/10 border-border/30 text-white placeholder:text-white/50"
              value={headerLoginData.password}
              name="password"
              onChange={handleHeaderLoginChange}
            />
            <Button size="sm" onClick={handleHeaderLoginSubmit} className="bg-primary hover:bg-primary/90">
              Login
            </Button>
          </div>

          <div className="md:hidden">
            <Link href="/register">
              <Button size="sm" variant="outline" className="border-primary/50 text-primary">
                Register
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col md:flex-row items-center justify-center p-8">
        {/* Left side - Logo/Image */}
        <div className="w-full md:w-1/2 flex flex-col items-center justify-center p-8 animate-fade-in">
          <div className="max-w-md mx-auto text-center">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/workconnect-QF8ACZmgXX8qHFp2h8Y83aeS6TuYt5.png"
              alt="Work Connect"
              width={400}
              height={300}
              priority
              className="mx-auto mb-4"
            />
          </div>
        </div>

        {/* Right side - Login Form */}
        <div className="w-full md:w-1/2 flex items-center justify-center p-8 animate-fade-up">
          <Card className="w-full max-w-md bg-white">
            <CardHeader>
              <CardTitle className="text-2xl">Welcome back</CardTitle>
              <CardDescription>Log in to your Work Connect account</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="login-username">Username</Label>
                  <Input
                    id="login-username"
                    name="username"
                    placeholder="johndoe"
                    value={loginData.username}
                    onChange={handleLoginChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="login-password">Password</Label>
                    <Link href="#" className="text-xs text-primary hover:underline">
                      Forgot password?
                    </Link>
                  </div>
                  <Input
                    id="login-password"
                    name="password"
                    type="password"
                    placeholder="••••••••"
                    value={loginData.password}
                    onChange={handleLoginChange}
                    required
                  />
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? "Logging in..." : "Log in"}
                </Button>
              </form>
            </CardContent>
            <CardFooter className="flex justify-center">
              <p className="text-sm text-muted-foreground">
                Don't have an account?{" "}
                <Link href="/register" className="text-primary hover:underline">
                  Sign up
                </Link>
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

