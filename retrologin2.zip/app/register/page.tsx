"use client"

import type React from "react"
import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"

export default function Register() {
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [registerData, setRegisterData] = useState({
    username: "",
    password: "",
    email: "",
    dob: "",
  })
  const [loginData, setLoginData] = useState({
    username: "",
    password: "",
  })

  const handleRegisterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setRegisterData((prev) => ({ ...prev, [name]: value }))
  }

  const handleLoginChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setLoginData((prev) => ({ ...prev, [name]: value }))
  }

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Validate form data
      if (!registerData.username || !registerData.password || !registerData.email || !registerData.dob) {
        throw new Error("All fields are required")
      }

      // Register user via API
      const response = await fetch("/api/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(registerData),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to create user")
      }

      toast({
        title: "Registration successful!",
        description: "You can now log in with your credentials.",
        variant: "default",
      })

      // Redirect to login page
      setTimeout(() => {
        router.push("/login")
      }, 1500)
    } catch (error: any) {
      toast({
        title: "Registration failed",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Authenticate user via API
      const response = await fetch("/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(loginData),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Invalid username or password")
      }

      // Store current user in localStorage
      localStorage.setItem("currentUser", JSON.stringify(data))

      toast({
        title: "Login successful!",
        description: "Welcome back to Work Connect.",
        variant: "default",
      })

      // Redirect to dashboard
      setTimeout(() => {
        router.push("/dashboard")
      }, 1000)
    } catch (error: any) {
      toast({
        title: "Login failed",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-brand-navy">
      {/* Top Login Bar */}
      <div className="w-full bg-brand-navy border-b border-border/20 py-4">
        <div className="container flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo-vMfrZLih1W3LkSGeqZJj23w007Ybh2.png"
              alt="Work Connect Logo"
              width={32}
              height={32}
              className="w-8 h-8"
            />
            <span className="font-bold text-xl text-white">Work Connect</span>
          </div>

          <div className="hidden md:flex items-center gap-3">
            <Input
              placeholder="Username"
              className="w-48 h-9 bg-background/10 border-border/30 text-white placeholder:text-white/50"
              value={loginData.username}
              name="username"
              onChange={handleLoginChange}
            />
            <Input
              placeholder="Password"
              type="password"
              className="w-48 h-9 bg-background/10 border-border/30 text-white placeholder:text-white/50"
              value={loginData.password}
              name="password"
              onChange={handleLoginChange}
            />
            <Button size="sm" onClick={handleLoginSubmit} className="bg-primary hover:bg-primary/90">
              Login
            </Button>
          </div>

          <div className="md:hidden">
            <Link href="/login">
              <Button size="sm" variant="outline" className="border-primary/50 text-primary">
                Login
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col md:flex-row items-center justify-center p-8">
        {/* Left side - Logo/Image */}
        <div className="w-full md:w-1/2 flex flex-col items-center justify-center p-8 animate-fade-in">
          <div className="max-w-md mx-auto text-center">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/workconnect-QF8ACZmgXX8qHFp2h8Y83aeS6TuYt5.png"
              alt="Work Connect"
              width={400}
              height={300}
              priority
              className="mx-auto mb-4"
            />
          </div>
        </div>

        {/* Right side - Registration Form */}
        <div className="w-full md:w-1/2 flex items-center justify-center p-8 animate-fade-up">
          <Card className="w-full max-w-md bg-white">
            <CardHeader>
              <CardTitle className="text-2xl">Create an account</CardTitle>
              <CardDescription>Enter your information to get started with Work Connect</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleRegisterSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input
                    id="username"
                    name="username"
                    placeholder="johndoe"
                    value={registerData.username}
                    onChange={handleRegisterChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    placeholder="••••••••"
                    value={registerData.password}
                    onChange={handleRegisterChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="john.doe@example.com"
                    value={registerData.email}
                    onChange={handleRegisterChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dob">Date of Birth</Label>
                  <Input
                    id="dob"
                    name="dob"
                    type="date"
                    value={registerData.dob}
                    onChange={handleRegisterChange}
                    required
                  />
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? "Creating account..." : "Sign Up"}
                </Button>
              </form>
            </CardContent>
            <CardFooter className="flex justify-center">
              <p className="text-sm text-muted-foreground">
                Already have an account?{" "}
                <Link href="/login" className="text-primary hover:underline">
                  Log in
                </Link>
              </p>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

