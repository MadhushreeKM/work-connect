import fs from "fs"
import path from "path"
import { calculateAge } from "./utils"

// Path to users.json file - ensuring it's in the src directory
const USERS_FILE_PATH = path.join(process.cwd(), "src", "users.json")

// Ensure the directory exists
export const ensureDirectoryExists = () => {
  const dir = path.dirname(USERS_FILE_PATH)
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true })
  }
}

// Read users from JSON file
export const readUsersFromFile = () => {
  ensureDirectoryExists()

  if (!fs.existsSync(USERS_FILE_PATH)) {
    fs.writeFileSync(USERS_FILE_PATH, JSON.stringify([], null, 2))
    return []
  }

  try {
    const data = fs.readFileSync(USERS_FILE_PATH, "utf8")
    return JSON.parse(data)
  } catch (error) {
    console.error("Error reading users file:", error)
    // If there's an error reading the file, create a new empty file
    fs.writeFileSync(USERS_FILE_PATH, JSON.stringify([], null, 2))
    return []
  }
}

// Write users to JSON file
export const writeUsersToFile = (users: any[]) => {
  ensureDirectoryExists()
  fs.writeFileSync(USERS_FILE_PATH, JSON.stringify(users, null, 2))
}

// Create a new user
export const createUser = (userData: any) => {
  // Read existing users
  const users = readUsersFromFile()

  // Check if username already exists
  if (users.some((user: any) => user.username === userData.username)) {
    throw new Error("Username already exists")
  }

  // Generate next ID (sequential starting from 1)
  const nextId = users.length > 0 ? String(Math.max(...users.map((user: any) => Number.parseInt(user.id))) + 1) : "1"

  // Calculate age from DOB
  const age = calculateAge(new Date(userData.dob))

  // Create new user in the exact format shown in the screenshot
  const newUser = {
    id: nextId,
    username: userData.username,
    password: userData.password,
    email: userData.email,
    DOB: userData.dob,
    age: age,
  }

  // Add to users array
  users.push(newUser)

  // Save to file
  writeUsersToFile(users)

  return newUser
}

// Authenticate user
export const authenticateUser = (username: string, password: string) => {
  const users = readUsersFromFile()
  return users.find((user: any) => user.username === username && user.password === password)
}

// Update user
export const updateUser = (id: string, userData: any) => {
  const users = readUsersFromFile()
  const userIndex = users.findIndex((user: any) => user.id === id)

  if (userIndex === -1) {
    throw new Error("User not found")
  }

  // Update user
  const updatedUser = {
    ...users[userIndex],
    ...userData,
  }

  // Recalculate age if DOB was updated
  if (userData.DOB || userData.dob) {
    const dobValue = userData.DOB || userData.dob
    updatedUser.age = calculateAge(new Date(dobValue))
    // Ensure DOB key is used consistently
    updatedUser.DOB = dobValue
    delete updatedUser.dob
  }

  users[userIndex] = updatedUser

  // Save to file
  writeUsersToFile(users)

  return updatedUser
}

