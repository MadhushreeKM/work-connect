import fs from "fs"
import path from "path"

interface User {
  id: string
  username: string
  password: string
  email: string
  dob: string
  age: number
  phone?: string
  profilePicture?: string
}

// Path to users.json file
const USERS_FILE_PATH = path.join(process.cwd(), "src", "users.json")

// Helper function to read users from JSON file
const readUsersFromFile = (): User[] => {
  try {
    // Check if file exists
    if (!fs.existsSync(USERS_FILE_PATH)) {
      // Create directory if it doesn't exist
      const dir = path.dirname(USERS_FILE_PATH)
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true })
      }
      // Create empty users array file
      fs.writeFileSync(USERS_FILE_PATH, JSON.stringify([], null, 2))
      return []
    }

    const data = fs.readFileSync(USERS_FILE_PATH, "utf8")
    return JSON.parse(data)
  } catch (error) {
    console.error("Error reading users file:", error)
    return []
  }
}

// Helper function to write users to JSON file
const writeUsersToFile = (users: User[]): boolean => {
  try {
    // Create directory if it doesn't exist
    const dir = path.dirname(USERS_FILE_PATH)
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true })
    }

    fs.writeFileSync(USERS_FILE_PATH, JSON.stringify(users, null, 2))
    return true
  } catch (error) {
    console.error("Error writing users file:", error)
    return false
  }
}

// Client-side version that uses localStorage as a fallback
const getUsers = (): User[] => {
  if (typeof window !== "undefined") {
    try {
      return JSON.parse(localStorage.getItem("users") || "[]")
    } catch (error) {
      console.error("Error getting users from localStorage:", error)
      return []
    }
  }
  return []
}

const saveUsers = (users: User[]): boolean => {
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem("users", JSON.stringify(users))
      return true
    } catch (error) {
      console.error("Error saving users to localStorage:", error)
      return false
    }
  }
  return false
}

export const UserService = {
  // Get all users
  getUsers: (): User[] => {
    // Try to read from file first, fall back to localStorage
    const fileUsers = readUsersFromFile()
    if (fileUsers.length > 0) {
      return fileUsers
    }
    return getUsers()
  },

  // Get user by ID
  getUserById: (id: string): User | null => {
    const users = UserService.getUsers()
    return users.find((user: User) => user.id === id) || null
  },

  // Get user by username
  getUserByUsername: (username: string): User | null => {
    const users = UserService.getUsers()
    return users.find((user: User) => user.username === username) || null
  },

  // Create new user
  createUser: async (userData: Omit<User, "id">): Promise<User | null> => {
    try {
      const users = UserService.getUsers()

      // Check if username already exists
      if (users.some((user: User) => user.username === userData.username)) {
        throw new Error("Username already exists")
      }

      // Generate next ID based on existing users
      const nextId = users.length > 0 ? String(Math.max(...users.map((user) => Number.parseInt(user.id))) + 1) : "1"

      // Create new user with ID
      const newUser: User = {
        ...userData,
        id: nextId,
      }

      // Add to users array
      users.push(newUser)

      // Save to file and localStorage
      writeUsersToFile(users)
      saveUsers(users)

      return newUser
    } catch (error) {
      console.error("Error creating user:", error)
      throw error
    }
  },

  // Update user
  updateUser: async (id: string, userData: Partial<User>): Promise<User | null> => {
    try {
      const users = UserService.getUsers()

      // Find user index
      const userIndex = users.findIndex((user: User) => user.id === id)

      if (userIndex === -1) {
        throw new Error("User not found")
      }

      // Update user
      const updatedUser = {
        ...users[userIndex],
        ...userData,
      }

      users[userIndex] = updatedUser

      // Save to file and localStorage
      writeUsersToFile(users)
      saveUsers(users)

      return updatedUser
    } catch (error) {
      console.error("Error updating user:", error)
      throw error
    }
  },

  // Delete user
  deleteUser: (id: string): boolean => {
    try {
      const users = UserService.getUsers()

      // Filter out user
      const filteredUsers = users.filter((user: User) => user.id !== id)

      // Save to file and localStorage
      writeUsersToFile(filteredUsers)
      saveUsers(filteredUsers)

      return true
    } catch (error) {
      console.error("Error deleting user:", error)
      return false
    }
  },

  // Authenticate user
  authenticateUser: (username: string, password: string): User | null => {
    const users = UserService.getUsers()

    // Find user with matching username and password
    const user = users.find((u: User) => u.username === username && u.password === password)

    return user || null
  },
}

