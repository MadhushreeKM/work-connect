import fs from "fs"
import path from "path"
import { calculateAge } from "./utils"

// Path to users.json file
const USERS_FILE_PATH = path.join(process.cwd(), "src", "users.json")

// Ensure the directory exists
export const ensureDirectoryExists = () => {
  const dir = path.dirname(USERS_FILE_PATH)
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true })
  }
}

// Read users from JSON file
export const readUsersFromFile = () => {
  ensureDirectoryExists()

  if (!fs.existsSync(USERS_FILE_PATH)) {
    fs.writeFileSync(USERS_FILE_PATH, JSON.stringify([], null, 2))
    return []
  }

  const data = fs.readFileSync(USERS_FILE_PATH, "utf8")
  return JSON.parse(data)
}

// Write users to JSON file
export const writeUsersToFile = (users: any[]) => {
  ensureDirectoryExists()
  fs.writeFileSync(USERS_FILE_PATH, JSON.stringify(users, null, 2))
}

// Create a new user
export const createUser = (userData: any) => {
  const users = readUsersFromFile()

  // Check if username already exists
  if (users.some((user: any) => user.username === userData.username)) {
    throw new Error("Username already exists")
  }

  // Generate next ID
  const nextId = users.length > 0 ? String(Math.max(...users.map((user: any) => Number.parseInt(user.id))) + 1) : "1"

  // Calculate age from DOB
  const age = calculateAge(new Date(userData.dob))

  // Create new user
  const newUser = {
    id: nextId,
    username: userData.username,
    password: userData.password,
    email: userData.email,
    dob: userData.dob,
    age,
    phone: userData.phone || "",
    profilePicture: userData.profilePicture || "",
  }

  // Add to users array
  users.push(newUser)

  // Save to file
  writeUsersToFile(users)

  return newUser
}

// Authenticate user
export const authenticateUser = (username: string, password: string) => {
  const users = readUsersFromFile()

  // Find user with matching username and password
  return users.find((user: any) => user.username === username && user.password === password)
}

// Update user
export const updateUser = (id: string, userData: any) => {
  const users = readUsersFromFile()

  // Find user index
  const userIndex = users.findIndex((user: any) => user.id === id)

  if (userIndex === -1) {
    throw new Error("User not found")
  }

  // Update user
  const updatedUser = {
    ...users[userIndex],
    ...userData,
  }

  // Recalculate age if DOB was updated
  if (userData.dob) {
    updatedUser.age = calculateAge(new Date(userData.dob))
  }

  users[userIndex] = updatedUser

  // Save to file
  writeUsersToFile(users)

  return updatedUser
}

