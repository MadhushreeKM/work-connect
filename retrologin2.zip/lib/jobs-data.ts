// Generate a large number of jobs
function generateJobs(count: number) {
  const companies = [
    "TechCorp",
    "DataSystems",
    "CreativeMinds",
    "CloudTech",
    "InnovateCo",
    "AnalyticsPro",
    "DevWorks",
    "DigitalSolutions",
    "FutureTech",
    "CodeCraft",
    "WebWizards",
    "DataDynamics",
    "TechFusion",
    "ByteBuilders",
    "PixelPerfect",
    "CloudNine",
    "InnovateX",
    "TechTitans",
    "CodeNexus",
    "DigitalDreams",
  ]

  const locations = [
    "San Francisco, CA",
    "New York, NY",
    "Austin, TX",
    "Chicago, IL",
    "Seattle, WA",
    "Boston, MA",
    "Los Angeles, CA",
    "Denver, CO",
    "Atlanta, GA",
    "Miami, FL",
    "Portland, OR",
    "Dallas, TX",
    "Washington, DC",
    "Phoenix, AZ",
    "Philadelphia, PA",
    "Remote",
    "Hybrid",
    "Remote (US)",
    "Remote (Global)",
    "Hybrid (US)",
  ]

  const jobTitles = [
    "Frontend Developer",
    "Backend Engineer",
    "UX/UI Designer",
    "DevOps Engineer",
    "Product Manager",
    "Data Scientist",
    "Full Stack Developer",
    "Mobile Developer",
    "QA Engineer",
    "Project Manager",
    "Technical Writer",
    "Systems Administrator",
    "Cloud Architect",
    "Machine Learning Engineer",
    "Blockchain Developer",
    "Security Engineer",
    "Database Administrator",
    "Network Engineer",
    "Game Developer",
    "AR/VR Developer",
    "AI Specialist",
    "Software Engineer",
    "Web Developer",
    "IT Support Specialist",
    "Business Analyst",
  ]

  const skills = [
    "React",
    "TypeScript",
    "Next.js",
    "Tailwind CSS",
    "Node.js",
    "Python",
    "AWS",
    "MongoDB",
    "Figma",
    "Adobe XD",
    "User Research",
    "Prototyping",
    "Docker",
    "Kubernetes",
    "CI/CD",
    "Product Strategy",
    "Agile",
    "User Stories",
    "Roadmapping",
    "Machine Learning",
    "SQL",
    "Data Visualization",
    "JavaScript",
    "HTML",
    "CSS",
    "Vue.js",
    "Angular",
    "Express",
    "Django",
    "Flask",
    "Ruby on Rails",
    "Java",
    "Spring Boot",
    "C#",
    ".NET",
    "PHP",
    "Laravel",
    "Swift",
    "Kotlin",
    "Flutter",
    "React Native",
    "GraphQL",
    "REST API",
    "Git",
    "Jira",
    "Confluence",
    "Scrum",
  ]

  const jobs = []

  for (let i = 1; i <= count; i++) {
    const companyIndex = Math.floor(Math.random() * companies.length)
    const locationIndex = Math.floor(Math.random() * locations.length)
    const titleIndex = Math.floor(Math.random() * jobTitles.length)

    // Generate random date within the last 30 days
    const postedDate = new Date()
    postedDate.setDate(postedDate.getDate() - Math.floor(Math.random() * 30))

    // Generate random salary range
    const baseSalary = 70000 + Math.floor(Math.random() * 100000)
    const salaryRange = 20000 + Math.floor(Math.random() * 40000)

    // Generate random tags (skills)
    const numTags = 3 + Math.floor(Math.random() * 4) // 3-6 tags
    const jobTags = []
    const usedIndexes = new Set()

    while (jobTags.length < numTags) {
      const skillIndex = Math.floor(Math.random() * skills.length)
      if (!usedIndexes.has(skillIndex)) {
        usedIndexes.add(skillIndex)
        jobTags.push(skills[skillIndex])
      }
    }

    jobs.push({
      id: i.toString(),
      title: jobTitles[titleIndex],
      company: companies[companyIndex],
      logo: `/placeholder.svg?height=80&width=80&text=${companies[companyIndex].charAt(0)}`,
      location: locations[locationIndex],
      type: Math.random() > 0.2 ? "Full-time" : Math.random() > 0.5 ? "Part-time" : "Contract",
      salary: { min: baseSalary, max: baseSalary + salaryRange },
      posted: postedDate.toISOString().split("T")[0],
      description: `We're looking for a talented ${jobTitles[titleIndex]} to join our team and help build amazing products that solve real-world problems.`,
      tags: jobTags,
    })
  }

  return jobs
}

export const jobsData = generateJobs(200)

